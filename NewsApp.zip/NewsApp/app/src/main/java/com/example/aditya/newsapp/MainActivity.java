package com.example.aditya.newsapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import java.util.ArrayList;

import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    /** Tag for the log messages */
    public static final String LOG_TAG = MainActivity.class.getSimpleName();

    private static final String key ="https://content.guardianapis.com/search?q=debate&tag=politics/politics&from-date=2014-01-01&api-key=dcd9ad5e-c852-4c47-bc8f-eab7f3411f07";

    private static final int EARTHQUAKE_LOADER_ID = 1;

    private NewsAdapter mAdapter;



            @Override
            protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView newsListView = (ListView) findViewById(R.id.list);

        mAdapter = new NewsAdapter(this, new ArrayList<News>());
        newsListView.setAdapter(mAdapter);

        newsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

            News currentNews = mAdapter.getItem(position);

            Uri newsUri = Uri.parse(currentNews.geturl());

            Intent websiteIntent = new Intent(Intent.ACTION_VIEW,   newsUri);

            startActivity(websiteIntent);
            }
        });
    }
    }