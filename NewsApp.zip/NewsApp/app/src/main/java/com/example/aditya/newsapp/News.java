package com.example.aditya.newsapp;

public class News {

public  String msection_event;

public  String mtitle_view;

public  String mauthor_name_view;

public final long mdate;

private String murl;
public News(String section_event, String title_view, String author_name_view, long date, String url){
    msection_event = section_event;
    mtitle_view = title_view;
    mauthor_name_view = author_name_view;
    mdate = date;
    murl= murl;
}

    public String getSection_event() {return msection_event; }

     public String gettitle_view()  {return mtitle_view; }

     public String getauther_name_view()    {return mauthor_name_view; }

     public long getdate()    {return mdate; }

    public String geturl()  {return murl;}
}
