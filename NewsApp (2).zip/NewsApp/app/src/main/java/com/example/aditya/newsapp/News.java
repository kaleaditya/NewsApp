package com.example.aditya.newsapp;

public class News {

public  String msection_event;

public  String mtitle_view;

public  String mauthor_name_view;

public final String mTimeInMilliseconds;

private String murl;
public News(String section_event, String title_view, String author_name_view, String TimeInMilliseconds, String url){
    msection_event = section_event;
    mtitle_view = title_view;
    mauthor_name_view = author_name_view;
    mTimeInMilliseconds = TimeInMilliseconds;
    murl= murl;
}

    public String getSection_event() {return msection_event; }

     public String gettitle_view()  {return mtitle_view; }

     public String getauthor_name_view()    {return mauthor_name_view; }

     public String getmTimeInMilliseconds()    {return mTimeInMilliseconds; }

    public String geturl()  {return murl;}
}
